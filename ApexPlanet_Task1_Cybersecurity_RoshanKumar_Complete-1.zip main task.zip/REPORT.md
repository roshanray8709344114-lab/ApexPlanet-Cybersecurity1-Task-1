# ApexPlanet Task 1 — Lab Setup Report

## Student Details
- **Name:** Roshan Kumar
- **Domain:** Cybersecurity & Ethical Hacking
- **Task:** 1

## Objective
To configure and verify a controlled virtual cybersecurity laboratory using Kali Linux and Metasploitable 2.

## Tools / Technologies
- Kali Linux
- Metasploitable 2
- Oracle VirtualBox
- Linux networking commands
- Ping
- Nmap (optional basic lab verification)

## Work Performed
- Started the virtual machines.
- Checked the IP addresses of both systems.
- Verified communication between Kali and Metasploitable.
- Documented the lab setup.
- Prepared evidence for the explanation video.

## Results
Fill this section with your actual values after completing the lab:

- Kali lab IP: `192.168.56.102`
- Metasploitable target IP: `192.168.56.101`
- Ping result: `4 packets transmitted, 4 received, 0% packet loss`
- ICMP capture: Verified in Wireshark on `eth1`

## Screenshots
Add the actual screenshots to the `screenshots/` folder and mention them here.

1. Kali IP and ping result — `screenshots/01-kali-ip-and-ping.jpg`
2. Ping verification — `screenshots/02-ping-verification.jpg`
3. Wireshark ICMP capture — `screenshots/03-wireshark-icmp-capture.jpg`

## Conclusion
The controlled virtual lab was prepared for cybersecurity learning and security testing. The network connection between the Kali Linux attacker machine and the intentionally vulnerable Metasploitable machine was verified before further practical exercises.

## Safety Note
All testing should remain limited to the user's own virtual machines or explicitly authorized systems.
