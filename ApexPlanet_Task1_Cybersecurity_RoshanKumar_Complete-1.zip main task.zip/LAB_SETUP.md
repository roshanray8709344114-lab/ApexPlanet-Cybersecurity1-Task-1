# Task 1 — Lab Setup Procedure

## 1. Start the Virtual Machines
Start Kali Linux and Metasploitable 2 in VirtualBox.

## 2. Check Kali IP
Open Terminal in Kali and run:

```bash
ip a
```

Record the IPv4 address belonging to the lab interface.

## 3. Login to Metasploitable
Use the credentials supplied with your own Metasploitable lab image.

Then run:

```bash
ifconfig
```

Record the IPv4 address.

## 4. Verify Connectivity
From Kali:

```bash
ping -c 4 <METASPLOITABLE_IP>
```

If replies are received, the lab network is communicating correctly.

## 5. Record Evidence
Take screenshots showing:
- Kali IP address
- Metasploitable IP address
- Successful ping
- VirtualBox network configuration (if required by the task)

Place the screenshots in the `screenshots/` folder.

## 6. Keep the Lab Isolated
Use a Host-Only or otherwise isolated VirtualBox network for the vulnerable target. Do not expose Metasploitable directly to the public Internet.
