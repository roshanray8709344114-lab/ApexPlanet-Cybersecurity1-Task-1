# ApexPlanet Cybersecurity & Ethical Hacking — Task 1

**Intern:** Roshan Kumar  
**Internship Domain:** Cybersecurity & Ethical Hacking  
**Task:** Task 1 — Cybersecurity Lab Setup  
**Environment:** Kali Linux + Metasploitable 2 (isolated virtual lab)

## Objective
The objective of this task is to prepare a controlled cybersecurity practice environment and understand basic networking between the attacker machine (Kali Linux) and the intentionally vulnerable target machine (Metasploitable 2).

## Lab Architecture
- Attacker: Kali Linux
- Target: Metasploitable 2
- Virtualization: Oracle VirtualBox
- Network: Host-Only / isolated lab network
- Purpose: Educational security testing only

## What I Practiced
1. Started Kali Linux and Metasploitable 2.
2. Checked the network interface and IP address on Kali.
3. Checked the IP address on Metasploitable.
4. Verified connectivity between the two virtual machines using `ping`.
5. Identified the target IP for use in the controlled lab.
6. Documented the setup and verification steps.

## Commands Used
See [COMMANDS.md](COMMANDS.md).

## Evidence
Screenshots from the actual lab session should be placed inside the `screenshots/` folder.

> **Important:** Replace any placeholder notes with your own screenshots/results before submission. Do not claim a command/result that was not actually performed.

## Video
The task walkthrough video is uploaded separately to LinkedIn and its link is submitted through the ApexPlanet internship portal.

## Disclaimer
This repository is for educational purposes and controlled laboratory testing only. Testing was intended for the user's own virtual machines and intentionally vulnerable lab systems.
