# Task 1 — Commands Used

## Kali Linux

Check interfaces and IP addresses:

```bash
ip a
```

Alternative:

```bash
hostname -I
```

Test connectivity to the Metasploitable IP:

```bash
ping -c 4 <METASPLOITABLE_IP>
```

## Metasploitable 2

After logging in, check the IP:

```bash
ifconfig
```

or:

```bash
ip addr
```

## Connectivity Verification

From Kali:

```bash
ping -c 4 <METASPLOITABLE_IP>
```

A successful response indicates that the two virtual machines can communicate over the configured lab network.

## Optional Lab Verification

Once the target IP is confirmed, basic service discovery in the isolated lab can be performed with:

```bash
nmap <METASPLOITABLE_IP>
```

Only use this against the intentionally vulnerable VM or systems for which you have permission.
